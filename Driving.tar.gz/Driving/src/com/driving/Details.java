package com.driving;
public class Details 
 {
	int id;
	String userName;
	String password;
	String emailId;
	String mobileNumber;
	int age;
	String address;
	
	public Details(int id,String userName,String password,String emailId,String mobileNumber,int age,String address)
	{
		this.id=id;
		this.userName=userName;
		this.password=password;
		this.emailId=emailId;
		this.mobileNumber=mobileNumber;
		this.age=age;
		this.address=address;
	}

}
 